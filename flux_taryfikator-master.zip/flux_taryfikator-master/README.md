# flux_taryfikator
Taryfikator na stronę internetową (html, css i javascript) - tylko polska wersja językowa.

# Opis
Moja pierwsza praca z htmlem, css i js w pełni stworzona od 0 przeze mnie. Jeżeli chodzi o samą zasadę działania nie ma tu nic skomplikowanego. Wybieracie sobie interesujące Was wykroczenie (można dopisać ilość), klikacie "ok" i sumuje Wam wszystko razem z treścią zarzutów. Jest to duże ułatwienie dla LSPD, można to odpalić sobie na przeglądarce na steam. Tablica zarzutów jest tworzona dynamicznie z pliku .js, więc tam ewentualnie musicie dodawać czy edytować wykroczenia.

W przyszłości jak znajdę czas być może połączę to z jakimś tabletem.


# Instalacja
Pobierasz, odpalasz plik index.html i to wszystko. Z wrzucaniem na hosting radźcie sobie sami. :D


# Licencja
Nie sprzedawaj ani nie udostępniaj tych plików innym osobom jako "twoje".
